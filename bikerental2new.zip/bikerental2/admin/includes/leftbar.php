	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i> Brands</a>
<ul>
<li><a href="create-brand.php">Create Brand</a></li>
<li><a href="manage-brands.php">Manage Brands</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-car"></i> Vehicles</a>
					<ul>
						<li><a href="post-avehical.php">Post a Vehicle</a></li>
						<li><a href="manage-vehicles.php">Manage Vehicles</a></li>
					</ul>
				</li>

<li><a href="#"><i class="fa fa-sitemap"></i> Bookings</a>
					<ul>
						<!-- <li><a href="new-bookings.php">New</a></li> -->
						<li><a href="Paid.php">Paid</a></li>
						<li><a href="confirmed-bookings.php">Confirmed</a></li>
						<li><a href="canceled-bookings.php">Cancelled</a></li>
						<!-- <li><a href="returned.php">Returned</a></li> -->
				
					</ul>
				</li>

		

				<!-- <li><a href="testimonials.php"><i class="fa fa-table"></i> Manage Testimonials</a></li> -->
				<!-- <li><a href="manage-conactusquery.php"><i class="fa fa-desktop"></i> Manage Conatctus Query</a></li> -->
				<li><a href="reg-users.php"><i class="fa fa-users"></i> Registered Users</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<!-- <li><a href="manage-conactusquery.php"><i class="fa fa-desktop"></i>Payments</a></li> -->
			<!-- ##################################################### -->
			<li><a href="testimonials.php"><i class="fa fa-files-o"></i>Sales</a></li>
			<!-- ############################################### -->


			<!-- <li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li> -->

			<!-- <li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Manage Subscribers</a></li> -->

			<!-- <li><a href="https://docs.google.com/spreadsheets/d/1dn4ILtdt4lyKhTNi5XM3zFH8PgZe9W52MtZYLwTUSQo/edit?fbclid=IwAR05FYqQW7sIU_7ro7G5z5VHh20QGGkGiWmIUt5zIBBGThWj9uUQfUz0Urk#gid=1265903897" target="_blank" rel="noopener noreferrer"><i class="fa fa-files-o"></i> Payments</a></li> -->
			<!-- <li><iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vRatZjxiAUYzbDwtsA_T2pGCsuySrzNrg_4DhDfM32TVxi_TuhQL_JAhJ_BWzVgExtlWefMWzMRgfgN/pubhtml?gid=1265903897&amp;single=true&amp;widget=true&amp;headers=false"></iframe></li> -->
			<!-- <li><a href="https://docs.google.com/spreadsheets/d/17IKaWFWT5y7QjyvhzO3UEOJyO-7o5rgV6sY7S60mW-g/edit#gid=1055085782" target="_blank" rel="noopener noreferrer"><i class="fa fa-files-o"></i> Sales</a></li> -->
			</ul>
		</nav>